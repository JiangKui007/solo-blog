title: Ubuntu18.04设置开机启动服务
date: '2019-07-30 12:19:17'
updated: '2019-07-30 12:19:17'
tags: [ubuntu]
permalink: /articles/2019/07/30/1564460357102.html
---
1. 复制命令（设置启动参数)   vi /lib/systemd/system/rc.local.service 
1.1. 复制代码（下面代码按ESC再 :wq 回车）
````
[Unit]
Description=/etc/rc.local Compatibility
Documentation=man:systemd-rc-local-generator(8)
ConditionFileIsExecutable=/etc/rc.local
After=syslog.target network.target remote-fs.target nss-lookup.target
 
[Service]
Type=forking
ExecStart=/etc/rc.local start
TimeoutSec=0
RemainAfterExit=no
GuessMainPID=no
 
````
#这一段原文件没有，需要自己添加
```
[Install]
WantedBy=multi-user.target
Alias=rc-local.service
```
 
2. 复制命令（设置软连接，开机启动回去/etc/……这个目录下去找文件）
```
ln -s /lib/systemd/system/rc.local.service /etc/systemd/system/rc.local.service
```
3.  复制命令（本身是没有rc.local文件的，后来上帝说要有它，就有了）
```
vi /etc/rc.local

```
3.1. 复制代码（要开机启动的脚本、服务或者其他的操作都把命令写入这个脚本）
```
#!/bin/bash
echo "hello" > /etc/test.log
/etc/init.d/webserver start
exit 0
```
4. reboot
