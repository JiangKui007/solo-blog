title: mac 设置定时关闭声音
date: '2019-09-03 10:48:20'
updated: '2019-09-03 10:48:20'
tags: [mac]
permalink: /articles/2019/09/03/1567478899990.html
---
有时候玩电脑，忘记关电脑声音，上班的时候突然响起来会很尴尬。

介绍一种mac上可以定时将电脑音量设为0的方法。

crontab + osascript

```
osascript -e "set volume 0"# 设置音量为0，最大为10

osascript -e "set volume output muted 1" # 设置全局静音
```

创建crontab
```
touch /etc/crontab

```
修改crontab
```
crontab -e
```

添加每日9点30 设置电脑音量为0的定时任务：
```
30 9 * * * osascript -e "set volume 0"

```
保存后退出。

重启crontab服务
```
sudo /usr/sbin/cron restart
```
这下再也不用担心上班的时候忘记关声音啦。
