title: ubuntu16.04 安装cuda9.0+cudnn7.0.5+tensorflow+nvidia-docker配置GPU服务器
date: '2019-06-13 22:39:07'
updated: '2019-06-13 22:39:07'
tags: [cuda, tensorflow, docker]
permalink: /articles/2019/06/13/1560436747075.html
---
查看nvidia使用状况：watch nvidia-smi

查看显卡信息：  lspci | grep -i vga

  

第一步：

删除之前的nvidia驱动：sudo apt-get purge nvidia-*

安装nvidia-<version> 此处version为396

n

此处需先配置ppa源，速度较慢，慢慢等吧，这里还没想出好办法解决。

sudo add-apt-repository ppa:graphics-drivers/ppa

  

更新源，运行 sudo apt-get update

查询nvidia驱动可用版本，运行sudo apt-cache search nvidia-* 查询相应版本

安装驱动，运行 sudo apt-get install nvidia-396

  

  

第二步：

安装cuda9.0

地址：[https://developer.nvidia.com/cuda-90-download-archive](https://developer.nvidia.com/cuda-90-download-archive) 选择相应版本，我这里用的ubuntu16.04 64x

wget [https://developer.nvidia.com/compute/cuda/9.0/Prod/local_installers/cuda-repo-ubuntu1604-9-0-local_9.0.176-1_amd64-deb](https://developer.nvidia.com/compute/cuda/9.0/Prod/local_installers/cuda-repo-ubuntu1604-9-0-local_9.0.176-1_amd64-deb)

  

根据提示安装：

1.  `sudo dpkg -i cuda-repo-ubuntu1604-9-0-local_9.0.176-1_amd64-deb`
2.  `sudo apt-key add /var/cuda-repo-9-0-local/7fa2af80.pub`
3.  `sudo apt-get update`
4.  `sudo apt-get install cuda`

这里有坑：遇到一些奇怪问题，总结如下：

（1）当遇到旧版本删除不够彻底时，会报

 下载 file:/var/cuda-repo-9-1-local/./nvidia-387-dev_387.26-0ubuntu1_amd64.deb  无法找到文件 - /var/cuda-repo-9-1-local/./nvidia-387-dev_387.26-0ubuntu1_amd64.deb (2: 没有那个文件或目录) 失败

错误，此时是判断为key错误，之前的9-1版本卸载后，key也删掉了，

使用命令`sudo apt-key add /var/cuda-repo-9-1-local/7fa2af80.pub`解决

（2）内核存在旧版本时，报错

正在处理用于 ureadahead (0.100.0-19) 的触发器 ...

在处理时有错误发生：

 initramfs-tools

E: Sub-process /usr/bin/dpkg returned an error code (1)

此时需要删除系统旧内核：

sudo vi /etc/default/grub

dpkg --get-selections|grep linux

![E0AD6659BF1F4F0D831C343AE204B48A.png](https://img.hacpai.com/file/2019/06/E0AD6659BF1F4F0D831C343AE204B48A-1ca0feb3.png)


选中旧版本，删除：

sudo apt-get remove linux-image-4.4.0-119-generic

再次查看版本：

![B3E34AFB4F93426EAEDA262D9DD4B6C8.png](https://img.hacpai.com/file/2019/06/B3E34AFB4F93426EAEDA262D9DD4B6C8-208f45bb.png)

看起来旧版本已经被删除了，

看一下系统内核版本：

uname -a

更新系统解决（initramfs-tools）问题：

sudo apt-get update

sudo apt-get upgrade  

重启电脑：

 sudo shutdown -r now

再次查看nvidia能够正常识别：

cat /proc/driver/nvidia/version

nvcc -V

nvidia-smi

  

（3）nvidia-smi报错

重装nvidia device

nvidia-smi

NVIDIA-SMI has failed because it couldn't communicate with the NVIDIA driver. Make sure that the latest NVIDIA driver is installed and running.

  

  

测试cuda（正确显示）：

nvidia-smi

  

![74A1EB35E4894658A2D077022EE4DBD7.png](https://img.hacpai.com/file/2019/06/74A1EB35E4894658A2D077022EE4DBD7-f17b1cf1.png)

  

  

第三步安装cudnn：

  

此处有坑，英伟达用国内ip登不上去，要翻墙登录后再下载，有些同学给了镜像，我这里下载的是：

libcudnn7_7.0.5.15-1+cuda9.0_amd64.deb

用runtime library

安装步骤与cuda相似：

chmod 777 ibcudnn7_7.0.5.15-1+cuda9.0_amd64.deb

sudo dpkg -i libcudnn7_7.0.5.15-1+cuda9.0_amd64.deb

  

等待安装，就好了

  

  

第四步：tensorflow-gpu安装

  

pip install tensorflow-gpu

  

安装完成 tensorflow-gpu，可以测试一下

进入ipython（以下为测试正常启动gpu画面）

importtensorflowastf

hello = tf.constant('Hello, TensorFlow!’)

sess = tf.Session()

![066F2CAEF93E421E8CA71F998D703264.png](https://img.hacpai.com/file/2019/06/066F2CAEF93E421E8CA71F998D703264-e6eca2ed.png)

  

接下来，要安装nvidia-docker了：

第五步：nvidia-docker

  

参考：[https://github.com/NVIDIA/nvidia-docker](https://github.com/NVIDIA/nvidia-docker)

＃如果你安装了nvidia-docker 1.0：我们需要删除它和所有现有的GPU容器

docker volume ls -q -f driver = nvidia-docker | xargs -r -I {} -n1 docker ps -q -a -f volume = {} | xargs -r docker rm -f

sudo apt-get purge -y nvidia-docker

  

＃添加软件包仓库

curl -s -L [https://nvidia.github.io/nvidia-docker/gpgkey](https://nvidia.github.io/nvidia-docker/gpgkey) | \

  sudo apt-key add  -

distribution = $（ ./ etc/os-release ; echo $ ID $ VERSION_ID ）

curl -s -L [https://nvidia.github.io/nvidia-docker/](https://nvidia.github.io/nvidia-docker/)$ distribution /nvidia-docker.list | \

  sudo tee /etc/apt/sources.list.d/nvidia-docker.list

sudo apt-get update

  

＃安装nvidia-docker2并重新加载Docker守护进程配置

sudo apt-get install -y nvidia-docker2

sudo pkill -SIGHUP dockerd

  

＃使用最新官方CUDA图像

  

docker run --runtime=nvidia --rm nvidia/cuda nvidia-smi

#### 

6.安装完成后，docker下载速度慢，报错：

error pulling image configuration: Get [https://dseasb33srnrn.cloudfront.net/registry-v2/docker/registry/v2/blobs/sha256/97/9782c71c14b7960794c9141f66721f7fff873d4de027b726c696ac1d54a99ce2/data?Expires=1524001324&Signature=EpbapfSa3ftVsuyhEHYwJjJILAzQhyf0iN4YQ1QpwXU9ITPlUhhIExWb6Efh~6ya3BkI44p3XvEI~SnrPPDyRYvsNRLbCc2qHhERV13J6BC7Ksylk54l75aKsigSHSFlmddvdR7Q1YszgKPEBFTAyMWzQ2GADaDKgMXjfN4W1Qk_&Key-Pair-Id=APKAJECH5M7VWIS5YZ6Q](https://dseasb33srnrn.cloudfront.net/registry-v2/docker/registry/v2/blobs/sha256/97/9782c71c14b7960794c9141f66721f7fff873d4de027b726c696ac1d54a99ce2/data?Expires=1524001324&Signature=EpbapfSa3ftVsuyhEHYwJjJILAzQhyf0iN4YQ1QpwXU9ITPlUhhIExWb6Efh~6ya3BkI44p3XvEI~SnrPPDyRYvsNRLbCc2qHhERV13J6BC7Ksylk54l75aKsigSHSFlmddvdR7Q1YszgKPEBFTAyMWzQ2GADaDKgMXjfN4W1Qk_&Key-Pair-Id=APKAJECH5M7VWIS5YZ6Q): net/http: TLS handshake timeout

  

 这是因为安装nvidia-docker会覆盖原来的/etc/docker/daemon.json文件

如果文件夹不存在：

sudo mkdir -p /etc/docker

  

打开 /etc/docker/daemon.json；

sudo mkdir -p /etc/docker

sudo tee /etc/docker/daemon.json <<-'EOF'

{

  "registry-mirrors": ["[https://4x0vrhen.mirror.aliyuncs.com](https://4x0vrhen.mirror.aliyuncs.com)"]

}

EOF

sudo systemctl daemon-reload

sudo systemctl restart docker

问题解决

  

  

  

在安装nvidia-docker2的时候，报错：

$ sudo apt-get install -y nvidia-docker2

正在读取软件包列表... 完成

正在分析软件包的依赖关系树      

正在读取状态信息... 完成      

有一些软件包无法被安装。如果您用的是 unstable 发行版，这也许是

因为系统无法达到您要求的状态造成的。该版本中可能会有一些您需要的软件

包尚未被创建或是它们已被从新到(Incoming)目录移出。

下列信息可能会对解决问题有所帮助：

  

下列软件包有未满足的依赖关系：

 nvidia-docker2 : 依赖: docker-ce (= 18.03.0~ce-0~ubuntu) 但无法安装它 或

                          docker-ee (= 18.03.0~ee-0~ubuntu) 但无法安装它

E: 无法修正错误，因为您要求某些软件包保持现状，就是它们破坏了软件包间的依赖关系。

  

首先打开清华源：

[https://mirrors.tuna.tsinghua.edu.cn/](https://mirrors.tuna.tsinghua.edu.cn/)

有两个镜像：docker和docker-ce

这里用docker-ce，因为nvidia-docker是基于docker-ce的：

最重要的几条命令：

删掉原来的docker：

sudo apt-get remove docker docker-engine [docker.io](http://docker.io)

sudo apt-get install apt-transport-https ca-certificates curl gnupg2 software-properties-common

  

这里注意了：

网上大部分的策略是：

curl -fsSL [https://download.docker.com/linux/debian/gpg](https://download.docker.com/linux/debian/gpg) | sudo apt-key add -

这句话没办法运行，因为被墙掉了：

改用清华的gpg：curl -fsSL [https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/ubuntu/gpg](https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/ubuntu/gpg) | sudo apt-key add -

sudo add-apt-repository \

   "deb [arch=amd64] [https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/ubuntu](https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/ubuntu) \

   $(lsb_release -cs) \

   stable"

  

sudo apt-get update

安装docker-ce和nvidia-docker2：

sudo apt-get install docker-ce

sudo apt-get install -y nvidia-docker2

 sudo pkill -SIGHUP dockerd

  

(4) 报如下错误时：

docker: Error response from daemon: OCI runtime create failed: container_linux.go:348: starting container process caused "process_linux.go:402: container init caused \"process_linux.go:385: running prestart hook 1 caused \\\"error running hook: exit status 1, stdout: , stderr: exec command: [/usr/bin/nvidia-container-cli --load-kmods configure --ldconfig=@/sbin/ldconfig.real --device=all --compute --utility --require=cuda>=9.0 --pid=24351 /var/lib/docker/aufs/mnt/085a2f9697d8b4dfbf269d413e032b46e948fa619e82f7a50b0dbac97e716be6]\\\\nnvidia-container-cli: initialization error: cuda error: no cuda-capable device is detected\\\\n\\\"\"": unknown.

  

可能是nvidia driver/cuda/nvidia-docker2之间出了问题；

将三者彻底删除

apt-get purge nvidia driver-* cuda-* nvidia-docker2

apt-get update

重新安装cuda-9-0，会自动安装相应的nvidia driver-384 就用默认的版本

测试nvidia-smi通过

重新安装nvidia-docker2，

测试 docker run --runtime=nvidia --rm nvidia/cuda nvidia-smi通过

 

问题解决

  

  

  

  

  

到这里，就完成了ubuntu16.04 安装cuda9.0+cudnn7.0.5+tensorflow+nvidia-docker配置GPU服务器

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

vidia docker配置加速源