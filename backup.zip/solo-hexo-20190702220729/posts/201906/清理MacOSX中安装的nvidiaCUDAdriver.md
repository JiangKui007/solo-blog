title: 清理Mac OSX中安装的nvidia CUDA driver
date: '2019-06-13 22:13:17'
updated: '2019-06-13 22:17:51'
tags: [mac]
permalink: /articles/2019/06/13/1560435197588.html
---
看到我的就MBP是nvidia的320M，没有仔细查阅资料，就以为支持CUDA，然后按照了CUDA driver，然后就看到Preference里提示不支持。那现在准备删除吧。

  

/usr/local/cuda

执行sudo rm -r /usr/local/cuda

/Library/Frameworks/CUDA.framework

执行sudo rm -f /Library/Frameworks/CUDA.framework

然后是Preference Pane里相关的文件里。

  

ls /Library/LaunchDaemons/*cuda*

/Library/LaunchDaemons/com.nvidia.cuda.launcher.plist

/Library/LaunchDaemons/com.nvidia.cudad.plist

  

$ cat  /Library/LaunchAgents/com.nvidia.CUDASoftwareUpdate.plist


  

把它们清理完就OK了。

  

$ sudo rm /Library/Preferences/*CUDA*

  

$ sudo rm -r /Library/PreferencePanes/CUDA\ Preferences.prefPane/

  

$ sudo rm /Library/LaunchDaemons/*cuda*