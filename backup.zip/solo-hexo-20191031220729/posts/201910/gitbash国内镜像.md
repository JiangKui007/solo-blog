title: git bash国内镜像
date: '2019-10-29 16:08:48'
updated: '2019-10-29 16:08:48'
tags: [Git]
permalink: /articles/2019/10/29/1572336528553.html
---
在官网下载速度慢，可以用这个国内镜像。
https://github.com/waylau/git-for-win