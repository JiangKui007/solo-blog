title: MAC禁用Adobe Creative Cloud自启状态栏
date: '2019-06-13 22:14:11'
updated: '2019-06-13 22:19:36'
tags: [mac]
permalink: /articles/2019/06/13/1560435251908.html
---
禁用Creative Cloud自启

launchctl unload -w /Library/LaunchAgents/com.adobe.AdobeCreativeCloud.plist

恢复

launchctl load -w /Library/LaunchAgents/com.adobe.AdobeCreativeCloud.plist