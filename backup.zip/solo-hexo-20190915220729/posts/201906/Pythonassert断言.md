title: Python——assert断言
date: '2019-06-13 22:43:23'
updated: '2019-06-13 22:43:23'
tags: [python]
permalink: /articles/2019/06/13/1560437003095.html
---
assert 能够快速提高debug速度。

  

断言是一种系统的方法，用于检查程序的内部状态是否与程序员预期的一样，目的是捕获错误。

  

特别是，它们有助于捕获在编写代码时所做的错误假设，或者被其他程序员滥用接口。此外，通过使程序员的假设显而易见，它们可以在一定程度上充当在线文档。

  

考虑放置断言的地方：

*   检查参数类型，类或值
*   检查数据结构常数
*   检查“不可能发生”的情况（列表中的重复，相互矛盾的状态变量。）
*   在调用函数之后，确保其返回是合理的

  

如果使用-O选项启动Python，则断言将被删除而不进行评估。因此，如果代码严重使用断言，但对性能至关重要，那么有一个系统可以在发布版本中关闭它们。（但除非真的有必要，否则不要这样做。）

  

[https://wiki.python.org/moin/UsingAssertionsEffectively](https://wiki.python.org/moin/UsingAssertionsEffectively)