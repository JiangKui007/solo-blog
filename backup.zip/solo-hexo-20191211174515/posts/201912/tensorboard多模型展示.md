title: tensorboard多模型展示
date: '2019-12-04 15:55:14'
updated: '2019-12-04 15:55:14'
tags: [TensorBoard]
permalink: /articles/2019/12/04/1575446114833.html
---
TensorBoard的官方教程中介绍了单模型的展示方式。

其实可以通过name的方式，指定多个模型，展示在TensorBoard。

命令如下：

tensorboard --logdir=name1:/path/to/logs/1,name2:/path/to/logs/2