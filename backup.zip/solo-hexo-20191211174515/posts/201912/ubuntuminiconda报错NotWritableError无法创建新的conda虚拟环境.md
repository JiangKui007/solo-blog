title: ubuntu miniconda 报错NotWritableError 无法创建新的conda虚拟环境
date: '2019-12-07 21:40:40'
updated: '2019-12-07 21:40:40'
tags: [miniconda, ubuntu, conda]
permalink: /articles/2019/12/07/1575726040293.html
---
```
NotWritableError: The current user does not have write permissions to a required path.

PermissionError: [Errno 13] Permission denied: '/home/deploy/.conda/envs’

```
  

提示envs没有权限。在相关的位置没有找到。在.conda文件夹下创建这个envs文件夹，并修改权限。
```

sudo mkdir /home/deploy/.conda/pkgs/envs

sudo chown 1001:1001 /home/deploy/.conda/pkgs/envs

```
  

  

```
    PermissionError: [Errno 13] Permission denied: '/home/deploy/.conda/pkgs/urls.txt’

```
同样pkgs/urls.txt也做相应的操作。

  
```

sudo mkdir /home/deploy/.conda/pkgs/

sudo touch /home/deploy/.conda/pkgs/urls.txt  

sudo chown 1001:1001 /home/deploy/.conda/pkgs/urls.txt

```
  

如果报错cache不存在，同样创建相应的文件夹，并改权限。

```
sudo mkdir /home/deploy/.conda/pkgs/cache

sudo chown 1001:1001 /home/deploy/.conda/pkgs/cache

```
  
接下来就可以创建conda环境了
conda create -n python36 python=3.6 anaconda