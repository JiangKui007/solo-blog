title: sklearn的十种分类器
date: '2019-10-29 16:14:45'
updated: '2019-10-29 16:14:45'
tags: [sklearn]
permalink: /articles/2019/10/29/1572336885172.html
---
sklearn是非常好用的机器学习科学计算库。

记录几种常见的机器学习分类器。

```
### KNN Classifier    
from sklearn.neighbors import KNeighborsClassifier
 
clf = KNeighborsClassifier()
clf.fit(train_x, train_y)
 
### Logistic Regression Classifier    
from sklearn.linear_model import LogisticRegression
 
clf = LogisticRegression(penalty='l2')
clf.fit(train_x, train_y)
 
### Random Forest Classifier    
from sklearn.ensemble import RandomForestClassifier
 
clf = RandomForestClassifier(n_estimators=8)
clf.fit(train_x, train_y)
 
### Decision Tree Classifier    
from sklearn import tree
 
clf = tree.DecisionTreeClassifier()
clf.fit(train_x, train_y)
 
### GBDT(Gradient Boosting Decision Tree) Classifier    
from sklearn.ensemble import GradientBoostingClassifier
 
clf = GradientBoostingClassifier(n_estimators=200)
clf.fit(train_x, train_y)
 
###AdaBoost Classifier
from sklearn.ensemble import  AdaBoostClassifier
 
clf = AdaBoostClassifier()
clf.fit(train_x, train_y)
 
### GaussianNB
from sklearn.naive_bayes import GaussianNB
 
clf = GaussianNB()
clf.fit(train_x, train_y)
 
### Linear Discriminant Analysis
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
 
clf = LinearDiscriminantAnalysis()
clf.fit(train_x, train_y)
 
### Quadratic Discriminant Analysis
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
 
clf = QuadraticDiscriminantAnalysis()
clf.fit(train_x, train_y)
 
### SVM Classifier    
from sklearn.svm import SVC
 
clf = SVC(kernel='rbf', probability=True)
clf.fit(train_x, train_y)
 
### Multinomial Naive Bayes Classifier    
from sklearn.naive_bayes import MultinomialNB
 
clf = MultinomialNB(alpha=0.01)
clf.fit(train_x, train_y)
```
