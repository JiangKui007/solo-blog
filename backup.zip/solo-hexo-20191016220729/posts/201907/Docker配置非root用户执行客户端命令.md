title: Docker配置非root用户执行客户端命令
date: '2019-07-30 12:16:40'
updated: '2019-07-30 12:16:40'
tags: [docker]
permalink: /articles/2019/07/30/1564460200137.html
---
        在执行Docker客户端命令时，因为涉及一些系统根目录的操作，因此，需要切换到root用户权限执行，但是这样权限管理就难处理了，可以配置非root用户也可以执行docker客户端命令，步骤如下：

1. 创建docker组

sudo groupadd docker

2. 当前登录用户加入到新建的docker组

sudo gpasswd -a ${USER} docker

3. 重启docker服务

sudo systemctl restart docker

4. 当前用户重新登录即可执行docker ps等命令了。
