title: Tensorflow Serving Docker compose 部署服务细节(Ubuntu&MacOS)
date: '2019-06-26 20:11:41'
updated: '2019-06-26 20:17:19'
tags: [docker, tensorflow, serving]
permalink: /articles/2019/06/26/1561551101511.html
---
前期准备：
homebrew
docker(配置好加速镜像)
![11.png](https://img.hacpai.com/file/2019/06/11-0af547a6.png)

docker-compose
![2.png](https://img.hacpai.com/file/2019/06/2-36ebea85.png)


TensorFlow Serving GitHub地址：
https://github.com/tensorflow/serving

建立docker-compose 文件目录
![3.png](https://img.hacpai.com/file/2019/06/3-4585987f.png)

在serving和tensorflow下分别建立docker-compose.yml文件。
![4.png](https://img.hacpai.com/file/2019/06/4-56d928c7.png)

一、下载安装测试TensorFlow Serving正常运行

拉取最近版本的docker

![5.png](https://img.hacpai.com/file/2019/06/5-effb1203.png)


二、用tensorflow训练模型并导出model文件

以鸢尾花为例

首先将训练好的模型导出为*.pd的model文件。

estimator导出方法用

tf.estimator.export.ServingInputReceiver(features, receiver_tensors)

导出model文件后，记录model的存放地址<export path>
https://www.tensorflow.org/guide/saved_model#prepare_serving_inputs

模型查看

saved_model_cli show --dir <export path> --all
![6.png](https://img.hacpai.com/file/2019/06/6-80598368.png)

https://www.tensorflow.org/tutorials/keras/save_and_restore_models （有示例代码）



三、使用serving

单模型测试及演示POST请求。介绍JSON设计

docker-compose.yml文件示例：
![7.png](https://img.hacpai.com/file/2019/06/7-97d9df9b.png)


.env 文件配置
![8.png](https://img.hacpai.com/file/2019/06/8-fcec3f28.png)




MODEL_PATH=/home/deploy/notebooks/jupyter_notebooks_13/bolt/model2/2
IRIS_MODEL_PATH=/home/deploy/notebooks/jupyter_notebooks_13/iris
IRIS_MODEL_NAME=iris
MODEL_NAME=bolt

单模型部署和多模型部署：
https://github.com/tensorflow/serving/blob/master/tensorflow_serving/g3doc/serving_config.md

models.config文件示例：
![9.png](https://img.hacpai.com/file/2019/06/9-89b636c9.png)


https://www.tensorflow.org/tfx/tutorials/serving/rest_simple

成功部署多模型多版本tensorflow serving
![10.png](https://img.hacpai.com/file/2019/06/10-569de6b2.png)
