title: Mac Launchpad(启动台）图标大小调整
date: '2019-12-06 09:33:03'
updated: '2019-12-06 09:33:03'
tags: [mac]
permalink: /articles/2019/12/06/1575595983451.html
---
**Mac在采用高分辨率模式下，Launchpad会变超级大，占用过多空间不宜立刻寻找到App。**

**可以通过调整Launchpad每一行、和每一列图标的数量，来调整Launchpad图标大小。**

**具体方法如下：**

**在Terminal下执行一下命令：**

**defaults write com.apple.dock springboard-columns -int 10**

**defaults write com.apple.dock springboard-rows -int 8**

**defaults write com.apple.dock ResetLaunchPad -bool TRUE**

**killall Dock**

**1、调整每一列显示图标数量，10表示每一列显示10个，比较不错，可根据个人喜好进行设置。 defaults write com.apple.dock springboard-rows -int 10**

**2、调整多少行显示图标数量，这里我用的是8 **

**defaults write com.apple.dock springboard-rows -int 8  
**

**3、重置Launchpad**

**defaults write com.apple.dock ResetLaunchPad -bool TRUE  
**

**4、重启Dock**

**killall Dock**

  
**恢复默认设置的方法。**

**以下是恢复默认大小的命令（在Terminal执行即可）：**

**defaults write com.apple.dock springboard-rows Default**

**defaults write com.apple.dock springboard-columns Default**

**defaults write com.apple.dock ResetLaunchPad -bool TRUE  
**

**killall Dock**

