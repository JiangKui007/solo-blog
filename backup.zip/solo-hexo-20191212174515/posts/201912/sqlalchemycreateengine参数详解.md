title: sqlalchemy create_engine 参数详解
date: '2019-12-04 17:18:13'
updated: '2019-12-04 17:18:13'
tags: [mysql, sqlalchemy]
permalink: /articles/2019/12/04/1575451093062.html
---
sqlalchemy使用 create_engine() 函数从URL生成一个数据库链接对象，URL遵循 RFC-1738标准。我也不懂。大概就是要有用户名，密码，地址，端口，数据库名，还有一些可选参数。一个标准的链接URL是这样的：

dialect+driver://username:password@host:port/database

dialect，是数据库类型，大概包括：sqlite, mysql, postgresql, oracle, or mssql.

driver，是使用的数据库API，驱动，连接包，随便叫什么吧。

username，用户名

password，密码

host，网络地址，可以用ip，域名，计算机名，当然是你能访问到的。

port，数据库端口。

databas，数据库名。

其实这些也就dialect和dirver需要解释。