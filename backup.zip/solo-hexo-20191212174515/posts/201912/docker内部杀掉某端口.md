title: docker 内部杀掉某端口
date: '2019-12-04 10:15:22'
updated: '2019-12-04 15:32:53'
tags: [docker, TensorBoard]
permalink: /articles/2019/12/04/1575425722124.html
---
调试TensorBoard遇到这个错误。E1204。
  ```
E1204 01:39:44.909575 MainThread program.py:267] TensorBoard attempted to bind to port 6006, but it was already in use
```

杀掉TensorBoard的6006端口：

1、先找到6006端口对应的服务PID

lsof(list open files)是一个列出当前系统打开文件的工具。在linux环境下，任何事物都以文件的形式存在，通过文件不仅仅可以访问常规数据，还可以访问网络连接和硬件。所以如传输控制协议 (TCP) 和用户数据报协议 (UDP) 套接字等，系统在后台都为该应用程序分配了一个文件描述符，无论这个文件的本质如何，该文件描述符为应用程序与基础操作系统之间的交互提供了通用接口。

`lsof -i:6006
`
  
```

COMMAND   PID USER   FD   TYPE  DEVICE SIZE/OFF NODE NAME

tensorboa 429 root    5u  IPv4 3413218      0t0  TCP *:x11-6 (LISTEN)

tensorboa 429 root    7u  IPv4 7173026      0t0  TCP b47713edc802:x11-6->055eb92f86dc38c6967335290de2bad:50275 (ESTABLISHED)

tensorboa 429 root    8u  IPv4 7173027      0t0  TCP b47713edc802:x11-6->055eb92f86dc38c6967335290de2bad:50279 (ESTABLISHED)

tensorboa 429 root    9u  IPv4 7173030      0t0  TCP b47713edc802:x11-6->055eb92f86dc38c6967335290de2bad:50280 (ESTABLISHED)

tensorboa 429 root   10u  IPv4 7173031      0t0  TCP b47713edc802:x11-6->055eb92f86dc38c6967335290de2bad:50281 (ESTABLISHED)

```
  

docker中如果没有安装lsof的话，可以用文件管理系统安装。我这里以ubuntu为例：

`apt install lsof`

  

2、找到PID为429，杀掉：

`kill -9 429`

-9这里的意思为必杀。

  

用法详解：

kill -9， 这个强大和危险的命令迫使进程在运行时突然终止，进程在结束后不能自我清理。危害是导致系统资源无法正常释放，一般不推荐使用，除非其他办法都无效。 

  

当使用此命令时，一定要通过ps -ef确认没有剩下任何僵尸进程。只能通过终止父进程来消除僵尸进程。如果僵尸进程被init收养，问题就比较严重了。杀死init进程意味着关闭系统。 

  

如果系统中有僵尸进程，并且其父进程是init，而且僵尸进程占用了大量的系统资源，那么就需要在某个时候重启机器以清除进程表了。 

  注意：
TensorBoard是一个文件读取服务。直接杀掉不会影响内部进程。 

TensorBoard只是读取日志文件并在内存中生成基于它们的可视化,因此无需担心文件损坏等.

参考文献：

[https://blog.csdn.net/gzh0222/article/details/10134949](https://blog.csdn.net/gzh0222/article/details/10134949)