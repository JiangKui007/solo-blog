title: mac OS10.15无法使用conda命令解决办法
date: '2019-12-03 22:34:11'
updated: '2019-12-03 22:34:11'
tags: [mac]
permalink: /articles/2019/12/03/1575383651541.html
---
**问题：升级MAC OS至10.15，anaconda会出现无法使用conda命令。**  
**产生原因：因为之前更换了默认的shell把 bash 换成了 zsh**

The default interactive shell is now zsh.
To update your account to use zsh, please run `chsh -s /bin/zsh`.
For more details, please visit https://support.apple.com/kb/HT208050.

1.command+shift+. (显示隐藏文件)，打开访达-资源库-users,找到.bash_profile，复制全部内容并关闭。
2.打开命令行工具，vim ~/.zshrc,点击i进行编辑，粘贴刚才复制的内容，并加入：export PATH="你的路径/anaconda3/bin:$PATH”，点击esc,输入
:wq(保存)。
3.最后打开命令行工具，输入source ~/.zshrc，退出就好了。
