title: linux 开机启动
date: '2019-08-16 14:19:39'
updated: '2019-12-09 11:11:17'
tags: [linux, docker, 开机启动]
permalink: /articles/2019/08/16/1565936379412.html
---
1、systemd默认读取/etc/systemd/system下的配置文件，该目录下的文件会链接/lib/systemd/system/下的文件。一般系统安装完/lib/systemd/system/下会有rc-local.[service](https://www.centos.bz/tag/service/)文件，即我们需要的配置文件。  
链接过来：

```
ln -fs /lib/systemd/system/rc-local.service /etc/systemd/system/rc-local.service
cd /etc/systemd/system/  
cat rc-local.service 
```
rc-local.service内容

创建/etc/rc.local文件 权限755

文件内容：
```
#!/bin/bash
echo "hello" > /etc/test.log
/etc/init.d/webserver start
# shadowsocks 转发服务
sslocal -c /etc/shadowsocks.json -d start
echo "shadowsocks started" > /etc/test.log
# 启动yapi python zentao等docker镜像
docker start mongo-yapi yapi
docker start python
docker start zentao
echo "mongo-yapi yapi python zentao started" > /etc/test.log
exit 0
```