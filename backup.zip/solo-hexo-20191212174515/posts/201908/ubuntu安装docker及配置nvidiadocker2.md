title: ubuntu安装docker及配置nvidia-docker2
date: '2019-08-19 16:36:43'
updated: '2019-08-19 16:36:43'
tags: [待分类]
permalink: /articles/2019/08/19/1566203803236.html
---
docker安装官网地址：
https://docs.docker.com/install/linux/docker-ce/ubuntu/

1.删除旧版本docker
```
sudo apt-get remove docker docker-engine docker.io containerd runc 
```
2.更新系统

```
sudo apt-get update
```
3.安装基础包：
```
sudo apt-get install \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg-agent \
    software-properties-common
```
4.加入docker官方key
```
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add - 
```
`$ sudo apt-key fingerprint 0EBFCD88`

5. 配置apt仓库
```
$ sudo add-apt-repository \
   "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
   $(lsb_release -cs) \
   stable"
```
