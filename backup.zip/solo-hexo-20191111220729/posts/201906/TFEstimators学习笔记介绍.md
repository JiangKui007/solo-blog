title: TF_Estimators学习笔记 - 介绍
date: '2019-06-13 22:50:53'
updated: '2019-06-13 22:50:53'
tags: [tensorflow, estimator]
permalink: /articles/2019/06/13/1560437453784.html
---
一、简介

estimators是tensorflow的机器学习高阶API：

包括四个部分：

1.1、训练

1.2、评估

1.3、预测

1.4、服务导出

该api基于类：tf.estimator.Estimator.

二、优势

estimator有以下优势：

2.1、基于estimator的模型既可以在本地运行，也可以在分布式环境中运行，可以不修改代码同时在CPU、TPU、GPU服务器上运行

2.2、轻便的实现模型开发者之间的共享

2.3、更简单的时间模型

2.4、estimator是简化订制在tf.layers

2.5、自动图像化

2.6、提供安全的训练循环：·图像化、·内置变量、·启动队列、·异常管理、·从错误中创建和删除测点文件

  

三、pre-made(预制)

预制能够让开发者从更高层面工作。预制estimator为开发者创造和管理图和会话对象。

3.1、预制estimators程序结构

3.1.1 写一个或多个数据集导入函数（返回一个特征数据字典、一个包含标签的tensor）

  

```
def input_fn(dataset):
   ...  # manipulate dataset, extracting the feature dict and the label

   return feature_dict, label

```

3.1.2 定义特征列

    每一个tf.feature_column定义特征名、类型和任何输入预处理，举三个例子：

```
# Define three numeric feature columns.

population = tf.feature_column.numeric_column('population')
crime_rate = tf.feature_column.numeric_column('crime_rate')
median_education = tf.feature_column.numeric_column('median_education',
               normalizer_fn=lambda x: x - global_education_mean)
```

3.1.3 实例化预制estimator

举 LinearClassifier的例子：

```
# Instantiate an estimator, passing the feature columns.
estimator = tf.estimator.LinearClassifier(
    feature_columns=[population, crime_rate, median_education],
    )
```

3.1.4调用训练、评价、生成方法：

举train方法：

  

```
# my_training_set is the function created in Step 1

  

estimator.train(input_fn=my_training_set, steps=2000)

```
  

3.2、预制评估器的优势

 指明计算图在计算机和计算集群中何处运行的最佳实践

 普遍有用的事件总结最佳实践

  

四、订制评估器

订制评估器和预制评估器的核心，都是模型函数。

  

五、工作流推荐

5.1 假设合适的预制评估器存在，用它来构造第一个模型并建立基准线

5.2 构造和测试全局管道，包括对这个预制评估器的数据完整性和可靠性

5.3 对预制评估器做适当的修改，使他能够产生最佳结果

5.4 如果可以的话，建立自己的模型

  

六、从Keras models建立评估器

举例调用tf.keras.estimator.model_to_estimator
```

1.  # Instantiate a Keras inception v3 model.
2.  keras_inception_v3 = tf.keras.applications.inception_v3.InceptionV3(weights=None)
3.  # Compile model with the optimizer, loss, and metrics you'd like to train with.
4.  keras_inception_v3.compile(optimizer=tf.keras.optimizers.SGD(lr=0.0001, momentum=0.9),
5.                            loss='categorical_crossentropy',
6.                            metric='accuracy')
7.  # Create an Estimator from the compiled Keras model. Note the initial model
8.  # state of the keras model is preserved in the created Estimator.
9.  est_inception_v3 = tf.keras.estimator.model_to_estimator(keras_model=keras_inception_v3)
10.  # Treat the derived Estimator as you would with any other Estimator.
11.  # First, recover the input name(s) of Keras model, so we can use them as the
12.  # feature column name(s) of the Estimator input function:
13.  keras_inception_v3.input_names  # print out: ['input_1']
14.  # Once we have the input name(s), we can create the input function, for example,
15.  # for input(s) in the format of numpy ndarray:
16.  train_input_fn = tf.estimator.inputs.numpy_input_fn(
17.      x={"input_1": train_data},
18.      y=train_labels,
19.      num_epochs=1,
20.      shuffle=False)
21.  # To train, we call Estimator's train function:
22.  est_inception_v3.train(input_fn=train_input_fn, steps=2000)
```