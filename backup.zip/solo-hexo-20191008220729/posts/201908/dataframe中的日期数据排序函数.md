title: dataframe中的日期数据排序函数
date: '2019-08-14 16:33:43'
updated: '2019-09-04 11:21:46'
tags: [pandas, 排序]
permalink: /articles/2019/08/14/1565771623709.html
---
```
def sort_date(df):
    date_list = [n.strftime('%Y%m%d') for n in df.date.unique()]
    date_list.sort()
    return date_list
```