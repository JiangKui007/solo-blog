title: nvidia-smi使用方法
date: '2019-06-13 22:41:05'
updated: '2019-06-13 22:41:05'
tags: [nvidia, cuda]
permalink: /articles/2019/06/13/1560436865825.html
---
nvidia 的系统管理界面 (nvidia-smi)，可以收集各种级别的信息，查看显存使用情况。此外, 可以启用和禁用 GPU 配置选项 (如 ECC 内存功能)。

1. nvidia-smi 命令

  

  

解释相关参数含义：

  

GPU：本机中的GPU编号

  

Name：GPU 类型

  

Persistence-M：

  

Fan：风扇转速

  

Temp：温度，单位摄氏度

  

Perf：表征性能状态，从P0到P12，P0表示最大性能，P12表示状态最小性能

  

Pwr:Usage/Cap：能耗表示

  

Bus-Id：涉及GPU总线的相关信息；

  

Disp.A：Display Active，表示GPU的显示是否初始化

  

Memory-Usage：显存使用率

  

Volatile GPU-Util：浮动的GPU利用率

  

Uncorr. ECC：关于ECC的东西

  

Compute M.：计算模式

  

Processes 显示每块GPU上每个进程所使用的显存情况。

  

  

2. nvidia-smi -L 命令：列出所有可用的 NVIDIA 设备

  

  

  

  

3. nvidia-smi topo --matrix 命令：查看系统拓扑

  

要正确地利用更先进的 NVIDIA GPU 功能 (如 GPUDirect)，使用系统拓扑正确配置往往是至关重要的。该拓扑指的是 PCI Express 设备 (GPUs, InfiniBand HCAs, storage controllers, 等) 如何互相连接以及如何连接到系统的CPU。如果使用不正确的拓扑, 某些功能可能会减慢甚至停止工作。

  

  

  

  

4. nvidia-smi -q -d CLOCK 命令：查看当前的 GPU 时钟速度、默认时钟速度和最大可能的时钟速度

  

  

  

  

5. nvidia-smi -q -d SUPPORTED_CLOCKS ：显示每个 GPU 的可用时钟速度列表