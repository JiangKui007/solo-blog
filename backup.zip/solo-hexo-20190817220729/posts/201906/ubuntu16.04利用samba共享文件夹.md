title: ubuntu16.04利用samba共享文件夹
date: '2019-06-13 22:44:47'
updated: '2019-06-13 22:46:45'
tags: [ubuntu, smb]
permalink: /articles/2019/06/13/1560437087491.html
---
SAMBA是 SMB/CIFS网络协议的重新实现，它作为NFS的补充使得在Linux和Windows系统之间进行文件共享、打印更容易实现。

相关介绍SAMBA套件：

（1）samba：这个套件主要包含了SAMBA的主要daemon档案(smbd及nmbd)SAMBA的文档(document),以及其它与SAMBA相关的logrotate设定文件及开机预设选项档案等。

（2）samba-common:这个套件主要提供了SAMBA得主要设定档（smb.conf）,smb.conf语法检验的测试程序(testparm)等。

（3）samba-client:这个条件则提供了当Linux做为SAMBA Client端时，所需要的工具指令，例如挂载SAMBA档案格式的执行档smbmount等。

 

以下是在Ubuntu 16.04中的安装和配置过程：

需要说明的是：本人是jobs用户，共享目录为/home/jobs/share/

1、安装samba相关包：

sudo apt-get install samba

sudo apt-get install smbclient

2、修改配置文件：

sudo vi /etc/samba/smb.conf

在文件末尾加上如下[share]  （相当于在home目录项增加了一个新用户）


	![image.png](https://img.hacpai.com/file/2019/06/image-b95e7e08.png)

  

5、保存退出后重启samba：

sudo /etc/init.d/samba restart

或service smbdrestart && service nmbd restart

  

6、测试：

smbclient -L //localhost/share

  

  

七，使用

可以到windows下输入ip使用了，在文件夹处输入 "\\" + "Ubuntu机器的ip或主机名" + "\\" + "share"

  

  

如果在mac下的话，在Safari中输入 smb://[ip]/ 即可挂载到主机上