title: linux 开机启动项
date: '2019-08-16 14:19:39'
updated: '2019-08-16 14:19:39'
tags: [linux, docker, 开机启动]
permalink: /articles/2019/08/16/1565936379412.html
---
设置docker镜像开机启动及其他开机启动项

创建/etc/rc.local文件 权限755

文件内容：
```
#!/bin/bash
echo "hello" > /etc/test.log
/etc/init.d/webserver start
# shadowsocks 转发服务
sslocal -c /etc/shadowsocks.json -d start
echo "shadowsocks started" > /etc/test.log
# 启动yapi python zentao等docker镜像
docker start mongo-yapi yapi
docker start python
docker start zentao
echo "mongo-yapi yapi python zentao started" > /etc/test.log
exit 0
```