title: Mac 开启 crontab 定时任务调试
date: '2019-09-03 10:35:54'
updated: '2019-09-03 10:35:54'
tags: [mac, crontab]
permalink: /articles/2019/09/03/1567478154624.html
---
*参考文献：*http://linuxtools-rst.readthedocs.io/zh_CN/latest/tool/crontab.html

Mac使用开启crontab
查看 crontab 是否启动

```
  sudo launchctl list | grep cron
```
检查需要的文件

```
  $  LaunchAgents  ll /etc/crontab
  ls: /etc/crontab: No such file or directory  #表示没有这个文件，需要创建一个

```
创建文件

```
  sudo touch /etc/crontab	

```
crontab的参数
```
-u user：用来设定某个用户的crontab服务；

file：file是命令文件的名字,表示将file做为crontab的任务列表文件并载入crontab。如果在命令行中没有指定这个文件，crontab命令将接受标准输入（键盘）上键入的命令，并将它们载入crontab。

-e：编辑某个用户的crontab文件内容。如果不指定用户，则表示编辑当前用户的crontab文件。

-l：显示某个用户的crontab文件内容，如果不指定用户，则表示显示当前用户的crontab文件内容。

-r：从/var/spool/cron目录中删除某个用户的crontab文件，如果不指定用户，则默认删除当前用户的crontab文件。

-i：在删除用户的crontab文件时给确认提示。
```

eg: */1 * * * * /bin/date >> /User/Username(你的用户名)/time.txt表示每分钟输出当前时间到time.txt上.

如果出现以下问题
```

  [hayek@mac:/www/] 02:33:22 PM: crontab -e                                                                                                         
  crontab: no crontab for hayek - using an empty one
  crontab: "/usr/bin/vi" exited with status 1 

```
方法1：EDITOR=vim crontab -e 直接编辑，以后直接crontab -e直接打开就行。
方法2：export EDITOR=vim
方法3：向cron进程提交一个crontab文件之前，首先要设置环境变量EDITOR。cron进程根据它来确定使用哪个编辑器编辑crontab文件。9 9 %的UNIX和LINUX用户都使用vi，如果你也是这样，那么你就编辑$HOME目录下的. profile文件，在其中加入这样一行:
EDITOR=vi; export EDITOR
crontab的文件格式
```
	* 第1列分钟0～59
	* 第2列小时0～23（0表示子夜）
	* 第3列日1～31
	* 第4列月1～12
	* 第5列星期0～7（0和7表示星期天）
	* 第6列要运行的命令
```

crontab服务的重启关闭，开启
mac系统下

```
  sudo /usr/sbin/cron start
  sudo /usr/sbin/cron restart
  sudo /usr/sbin/cron stop
```

ubuntu:

```
  $sudo /etc/init.d/cron start
  $sudo /etc/init.d/cron stop
  $sudo /etc/init.d/cron restart
```

原文地址：http://biyongyao.com/archives/182
————————————————
版权声明：本文为CSDN博主「Bilyooyam」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/biyongyao/article/details/77791238