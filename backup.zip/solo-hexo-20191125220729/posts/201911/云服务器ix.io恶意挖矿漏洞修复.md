title: 云服务器ix.io恶意挖矿漏洞修复
date: '2019-11-21 10:17:33'
updated: '2019-11-21 10:17:33'
tags: [aliyun, 挖矿, ix.io, 漏洞]
permalink: /articles/2019/11/21/1574302653004.html
---
最近用阿里云服务器部署web服务。同事配置docker时开放了docker remote端口2375，这个端口可以远程上传docker镜像，发送docker指令。在本地部署时较方便，但在公网环境下部署，容易被黑客攻击。

相关文章参考：

[Docker出漏洞：端口2375【附案例】]( [http://www.91ri.org/15837.html](http://www.91ri.org/15837.html))

阿里云告警信息：
访问恶意域名、矿池通信行为、主动连接恶意下载源等。

告警出现后，首先排除了团队使用云服务器挖矿的可能。考虑应该是被恶意攻击了。
![noteattach1.jpeg](https://img.hacpai.com/file/2019/11/noteattach1-64ffb452.jpeg)

告警中提到了2375端口：
![124.jpg](https://img.hacpai.com/file/2019/11/124-745183f2.jpg)

web攻击来自法国的ip地址：
![123.jpg](https://img.hacpai.com/file/2019/11/123-03d8f9fc.jpg)

首先使用服务器安全组禁用云服务器的2375端口。
![125.jpg](https://img.hacpai.com/file/2019/11/125-c25b38b4.jpg)

使用htop查看系统进程，发现cpu被/var/tmp/sic/sic这个命令占满。
/var这个目录通常是用来放docker镜像的。因此应该是docker出了问题。

![noteattach3.png](https://img.hacpai.com/file/2019/11/noteattach3-dd5c256f.png)

先在htop界面按F9杀掉/var/tmp/sic/sic这个进程。
再到/var/tmp/目录下删掉所有sic文件夹。



删除这两个文件之后，问题临时解决了。但过一段时间又出现了这几个文件。阿里云又持续报警，CPU占满。
![noteattach.jpeg](https://img.hacpai.com/file/2019/11/noteattach-e0a507c6.jpeg)

查了相关资料，有可能是crontab中写入了定时程序：
[记一次两台服务器同时被挖矿的过程](     
[http://www.lzhpo.com/article/97](http://www.lzhpo.com/article/97))

因为是新部署的服务器，之前没有配置crontab，所以忽略了检查这个服务。
使用crontab -l 查看正在运行的定时服务。
![noteattach1.png](https://img.hacpai.com/file/2019/11/noteattach1-1f4555e1.png)

这两组crontab定时任务将每小时从ix.io下载脚本并执行。本地将ix.io的ip地址查到，考虑禁止访问这两个ip地址。
![noteattach2.png](https://img.hacpai.com/file/2019/11/noteattach2-135950f9.png)

ix.io脚本内容：
![noteattach.png](https://img.hacpai.com/file/2019/11/noteattach-d22f9448.png)

封禁ip地址：
![126.jpg](https://img.hacpai.com/file/2019/11/126-0ff747fe.jpg)

经过以上处理后，该挖矿漏洞被补上了。观察一天之后，恶意程序没有再启动。cpu运行正常。


