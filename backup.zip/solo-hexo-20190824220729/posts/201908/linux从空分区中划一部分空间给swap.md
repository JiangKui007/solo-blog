title: linux 从空分区中划一部分空间给swap
date: '2019-08-16 14:29:13'
updated: '2019-08-16 14:29:13'
tags: [linux, 磁盘挂载]
permalink: /articles/2019/08/16/1565936952941.html
---
几个命令：
```
# 查看磁盘信息
fdisk -l
fdisk /dev/sda -l
fdisk /dev/sda

#查看当前文件系统
df -h 

```

swap分区格式化要使用

`mkswap /dev/sdb5`


```
加载文件
swapon /dev/sdb5

查看是否生效
swapon -s
```
可以看到sda3,和sdb5这两个swap分区

 **8.挂载分区**

 这里直接使用修改文件的方式永久挂载

```
创建挂载文件路径
mkdir sdb1 sdb6
```
[135426201601031705088391646340670.png](https://img.hacpai.com/file/2019/08/135426201601031705088391646340670-a792c6f4.png)

[13542620160103172226385694222907.png](https://img.hacpai.com/file/2019/08/13542620160103172226385694222907-72e783db.png)!

[135426201601031723463391586447056.png](https://img.hacpai.com/file/2019/08/135426201601031723463391586447056-574f5e1e.png)!


![135426201601031733006511541859392.png](https://img.hacpai.com/file/2019/08/135426201601031733006511541859392-b8a8abbc.png)!



fdisk 帮助信息
```
命令(输入 m 获取帮助)： m

帮助：

  DOS (MBR)
   a   开关 可启动 标志
   b   编辑嵌套的 BSD 磁盘标签
   c   开关 dos 兼容性标志

  常规
   d   删除分区
   F   列出未分区的空闲区
   l   列出已知分区类型
   n   添加新分区
   p   打印分区表
   t   更改分区类型
   v   检查分区表
   i   打印某个分区的相关信息

  杂项
   m   打印此菜单
   u   更改 显示/记录 单位
   x   更多功能(仅限专业人员)

  脚本
   I   从 sfdisk 脚本文件加载磁盘布局
   O   将磁盘布局转储为 sfdisk 脚本文件

  保存并退出
   w   将分区表写入磁盘并退出
   q   退出而不保存更改

  新建空磁盘标签
   g   新建一份 GPT 分区表
   G   新建一份空 GPT (IRIX) 分区表
   o   新建一份的空 DOS 分区表
   s   新建一份空 Sun 分区表
```

参考链接：https://www.cnblogs.com/chenmh/p/5096592.html