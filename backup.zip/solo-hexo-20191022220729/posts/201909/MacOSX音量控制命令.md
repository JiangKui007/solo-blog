title: 'Mac OS X: 音量控制命令'
date: '2019-09-03 10:33:15'
updated: '2019-09-04 11:15:47'
tags: [mac]
permalink: /articles/2019/09/03/1567477995604.html
---
1. 设置开机音音量大小:

静音:

sudo nvram SystemAudioVolume=%80"

音量最小:

sudo nvram SystemAudioVolume=%00

音量最大:

sudo nvram SystemAudioVolume=2

注意: 当用户在OS X中改变音量后，这个系统值也会随着改变。

 

2. 使用script调节音量:

osascript -e "set volume 10"

最大音量＝10，最小＝1，静音＝0

 

也可以在不改变音量的情况下静音:

osascript -e "set volume output muted 1"  
打开声音－解除静音：

osascript -e "set volume output muted 0"

 

3. 如果要Mac读文本，可以用：

say "Hello"

 

4. 也可以用软件设置开机声音大小/静音, 之所以有这么多软件，因为即便是Apple的不同机器和操作系统之间也有可能不能彼此兼容:

[Startup Chime Stopper 3.1](http://www.macupdate.com/info.php/id/13170/startup-chime-stopper): http://www.macupdate.com/info.php/id/13170/startup-chime-stopper

[Psst](http://www.satsumac.com/Psst.php): http://www.satsumac.com/Psst.php

[StartupSound.prefPane](http://www5e.biglobe.ne.jp/~arcana/StartupSound/index.en.html): http://www5e.biglobe.ne.jp/~arcana/StartupSound/index.en.html

 

5. 开机声音虽然很多人不喜欢，但是它是Apple检测提示给用户，电脑是否工作正常的一个方法，如果电脑硬件有问题，会有不同的dong声。

 

6. 可以使用shell脚本来自己控制:

对于OS X 10.4可以编辑/etc/rc.shutdown.local，添加下面一行:

/usr/sbin/nvram SystemAudioVolume=%80

对于OS X 10.5因为已经不支持rc.shutdown.local方式了，所以可以使用LogoutHook的方式，对于LogoutHook的操作轻看我的另一个blog文章: [Mac OS X(L1-3): 登录/退出自动运行程序的设置](http://blog.csdn.net/afatgoat/archive/2009/02/15/3892291.aspx)

  
原文链接： [http://blog.csdn.net/afatgoat/article/details/3899819](http://blog.csdn.net/afatgoat/article/details/3899819)

本文转载自：http://blog.csdn.net/afatgoat/article/details/3899819