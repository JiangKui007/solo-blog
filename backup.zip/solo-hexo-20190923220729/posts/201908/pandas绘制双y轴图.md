title: pandas 绘制双y轴图
date: '2019-08-13 15:47:19'
updated: '2019-09-04 11:14:04'
tags: [pandas]
permalink: /articles/2019/08/13/1565682439720.html
---
设置第二条y轴，然后将ax传入df.plot
```
    ax1 = df.plot(x='x1', y='y1', figsize=(20,4))
    ax2 = ax1.twinx() 
    df.plot(x='x1', y='y2', figsize=(20,4), color='orange', ax=ax2)

```

![Gridpowervarietywithoutsidetemperaturein20151102.png](https://img.hacpai.com/file/2019/08/Gridpowervarietywithoutsidetemperaturein20151102-7dc2d9c0.png)
