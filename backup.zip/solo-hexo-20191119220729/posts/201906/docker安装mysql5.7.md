title: docker 安装mysql5.7
date: '2019-06-13 22:41:52'
updated: '2019-06-13 22:41:52'
tags: [docker, mysql]
permalink: /articles/2019/06/13/1560436912278.html
---
使用docker官方镜像安装mysql服务

  

1 拉取mysql镜像，

docker pull mysql:5.7

2 重命名镜像名

docker tag [library/mysql:5.7](http://hub.c.163.com/library/mysql:5.7) mysql:5.7

3 创建用于挂载的目录

sudo mkdir /titan/mysql/datadir #用于挂载mysql数据文件

sudo mkdir /titan/mysql/conf.d #用于挂载mysql配置文件

sudo chown edison:docker /titan #修改/titan目录拥有者

  

4 使用镜像创建容器

docker run --name mysql5.7 -p 3306:3306 -v /data/mysql/datadir:/var/lib/mysql -v /data/mysql/conf.d:/etc/mysql/conf.d -e MYSQL_ROOT_PASSWORD=titan889890 -d mysql:5.7

  

5、docker inspect 显示当前docker的运行配置