title: Sublime Text 多行编辑快捷键
date: '2019-08-15 15:26:45'
updated: '2019-08-15 15:26:45'
tags: [SublimeText]
permalink: /articles/2019/08/15/1565854004955.html
---
*   鼠标选中多行，按下 `Ctrl_Shift_L`或`Command_Shift_L` 即可同时编辑这些`行`；
*   鼠标选中文本，反复按 `Ctrl_D`或`Command_D` 即可继续向下同时选中下一个相同的文本进行同时编辑；
*   鼠标选中文本，按下 `Alt_F3` 或 `Ctrl_Command_G` 即可一次性选择全部的相同文本进行同时编辑；
*   `Shift_鼠标右键` 或 `Option_鼠标左键` 或`鼠标中键`可以用鼠标进行竖向`多行`选择；
*   `Ctrl_鼠标左键`或 `Command_鼠标左键`可以手动选择同时要编辑的多处文本。

  
