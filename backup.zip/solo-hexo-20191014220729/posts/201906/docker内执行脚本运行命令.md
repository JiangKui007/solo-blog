title: docker 内执行脚本 运行命令
date: '2019-06-26 20:14:11'
updated: '2019-06-26 20:15:22'
tags: [docker]
permalink: /articles/2019/06/26/1561551250964.html
---
docker run -i -t --name test111 -v 本机:容器内 -p 3000:3000 -p 18888:18888 --privileged=true node-mongo0901 sh -c 'service mongod start && npm run start'