title: mac OS X 设置环境变量相关
date: '2019-06-13 22:47:25'
updated: '2019-06-13 22:47:25'
tags: [mac]
permalink: /articles/2019/06/13/1560437245919.html
---
To set an environment variable, enter the following command:

launchctl setenv variable "value"

To find out if an environment variable is set, use the following command:

launchctl getenv variable

To clear an environment variable, use the following command:

launchctl unsetenv variable