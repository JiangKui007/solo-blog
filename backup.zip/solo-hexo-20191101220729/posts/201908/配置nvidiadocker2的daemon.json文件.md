title: 配置nvidia-docker2的daemon.json文件
date: '2019-08-19 16:42:58'
updated: '2019-08-19 16:42:58'
tags: [待分类]
permalink: /articles/2019/08/19/1566204178750.html
---
```
$ cat /etc/docker/daemon.json
{

    "runtimes": {
        "nvidia": {
            "path": "nvidia-container-runtime",
            "runtimeArgs": []
        }
    }
}
```